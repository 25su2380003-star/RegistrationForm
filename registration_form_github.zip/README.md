# Registration Form

A simple responsive HTML/CSS registration form.

## Files
- `index.html` - Registration form

## Run
Open `index.html` in a browser.

> Note: This is a frontend registration form. A backend is required to securely store and process registration data.
